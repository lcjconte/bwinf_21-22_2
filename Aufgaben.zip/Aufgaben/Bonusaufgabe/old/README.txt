Die in diesem Ordner vorliegenden Quelltext-Dateien stellen vergangene Iterationen des Programms dar
und enthalten deswegen Lücken.